import json, os, random, shutil, subprocess, sys, tempfile
from pathlib import Path
from contextlib import ExitStack
repo=Path('/Users/randlee/github/sc-compose-worktrees/sprint/w-6-adversarial-fuzz')
sys.path.insert(0,str(repo/'scripts'))
import integration_repour as h
import integration_repour_fuzz as f
kind, seed, port=sys.argv[1],int(sys.argv[2]),int(sys.argv[3])
shared_workspace=Path(sys.argv[4])
assert port != 3308
root=Path(tempfile.mkdtemp(prefix='case-',dir='/tmp/sc-shared-campaign')).resolve()
home, workspace=root/'home',root/'work'
home.mkdir(); workspace.mkdir()
env={k:v for k,v in os.environ.items() if not k.startswith(('BEADS_','BD_DOLT_'))}
env.update(HOME=str(home),USERPROFILE=str(home),XDG_CONFIG_HOME=str(home/'.config'),BEADS_DIR=str(shared_workspace/'.beads'),BEADS_NO_DAEMON='1',DOLT_ROOT_PATH=str(home),DOLT_DISABLE_EVENT_FLUSH='1',BD_DISABLE_EVENT_FLUSH='1',BD_DISABLE_METRICS='1',BD_DOLT_AUTO_PUSH='false',BD_DOLT_LOCAL_ONLY='true',SC_COMPOSE_TEST_DOLT_PORT=str(port))
bd='/opt/homebrew/bin/bd'; binary=str(repo/'target/debug/sc-compose')
def run(args, *, cwd, env, expected=0):
    result=subprocess.run(args,cwd=cwd,env=env,text=True,capture_output=True,timeout=120)
    print(json.dumps({'event':'command','args':args,'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr},ensure_ascii=False),flush=True)
    if result.returncode!=expected: raise AssertionError(f'expected {expected}: {args}: got {result.returncode}')
    return result
h.run=run
def bd_run(*args): return run([bd,*args],cwd=workspace,env=env).stdout
def cli(operation,path,*args,expected=0):
    return json.loads(run([binary,'bead',operation,str(path),*args,'--json'],cwd=workspace,env=env,expected=expected).stdout)
def show(bead): return json.loads(bd_run('show',bead,'--json'))[0]
def snapshot():
    rows=json.loads(bd_run('list','--all','-n','0','--json'))
    for row in rows:
        if 'dependencies' in row:
            row['dependencies'] = sorted(row['dependencies'], key=lambda d: json.dumps(d, sort_keys=True))
        if 'labels' in row:
            row['labels'] = sorted(row['labels'])
    return {r['id']:{'row':r,'deps':[{'id':d['depends_on_id'],'dependency_type':d['type']} for d in r.get('dependencies',[])]} for r in rows}
db=f'{kind}{seed}'
try:
    if kind=='struct':
        rng=random.Random(seed)
        names=(['alpha','beta','gamma','delta']+[f'node{i}' for i in range(16)]) if seed==12 else ['alpha','beta','gamma','delta','epsilon','zeta'][:4+seed%3]
        plans=[]
        for revision in range(7 if seed==12 else 3):
            active=[x for x in names if not (revision%3==1 and x=='delta')]
            if revision%3==1: active.append('delta_renamed')
            steps=[]
            for i,name in enumerate(active):
                needs=([active[i-1]] if i else []) if seed==12 and revision==0 else [active[j] for j in range(i) if rng.randrange(6)==0]
                steps.append({'id':name,'title':f'{name} seed {seed} revision {revision} '+rng.choice(('Unicode 雪 café', 'quotes \" and slash /', 'line\nfeed', 'long '+('x'*180))),'description':f'seed={seed}; revision={revision}; node={name}','priority':rng.randrange(5),'needs':needs})
            plans.append({'formula':f'fuzz_{seed}','steps':steps})
        f.plans_for_seed=lambda _:plans
        print(json.dumps({'event':'input','kind':kind,'seed':seed,'plans':plans},ensure_ascii=False),flush=True)
        print(f.run_seed(seed,workspace,cli,bd_run,show,snapshot),flush=True)
    else:
        source=Path('/tmp/sc-refusal-probe/probe.py' if kind=='refusal' else '/tmp/sc-partial-probe/probe.py').read_text()
        start=source.index("    path = workspace / 'refusal.formula.toml.j2'") if kind=='refusal' else source.index("    path = workspace/'partial.formula.toml.j2'")
        end=source.index("\nprint(",start)
        import textwrap
        body=textwrap.dedent(source[start:end])
        if kind=='refusal':
            body=body.replace('formula = \"refusal\"',f'formula = \"refusal_{seed}\"')
            body=body.replace('Alpha revised café',f'Alpha revised {seed} café').replace('missing-unicode-雪',f'missing-{seed}-雪').replace('dirty user change',f'dirty user change {seed}')
        else:
            body=body.replace("workspace/'partial.formula.toml.j2'",f"workspace/'partial_{seed}.formula.toml.j2'")
            body=body.replace('partial\"',f'partial_{seed}\"').replace("'formula_name':'partial'",f"'formula_name':'partial_{seed}'")
            body=body.replace('Alpha revised',f'Alpha revised {seed}')
        print(json.dumps({'event':'input','kind':kind,'seed':seed,'body':body},ensure_ascii=False),flush=True)
        exec(compile(body,f'<{kind}-{seed}>','exec'),globals(),locals())
    if seed == 5 and kind in ('struct','refusal'):
        exec(compile(Path('/tmp/sc-shared-campaign/extra.py').read_text(),'extra.py','exec'),globals())
        if kind=='struct': extras_struct()
        else: extras_refusal()
    print(json.dumps({'event':'case_assertions_passed','kind':kind,'seed':seed}),flush=True)
finally:
    shutil.rmtree(root)
