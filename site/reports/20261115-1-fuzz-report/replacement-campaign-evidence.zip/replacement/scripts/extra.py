def extras_struct():
    path=workspace/'conditional.formula.toml.j2'
    body='formula = "conditional"\nversion = 1\ntype = "workflow"\n[[steps]]\nid = "alpha"\ntitle = "Alpha"\n{% if extra == "yes" %}\n[[steps]]\nid = "optional"\ntitle = "Optional"\nneeds = ["alpha"]\n{% endif %}\n'
    path.write_text(body)
    print(json.dumps({'event':'conditional_input','template':body}),flush=True)
    initial=cli('pour',path,'--var','extra=yes')['payload']['graph']; root_id=initial['parent']; before=snapshot()
    preview=cli('repour',path,'--var','extra=no','--root',root_id,'--dry-run','--allow-uncommitted')['payload']['graph']
    assert snapshot()==before
    applied=cli('repour',path,'--var','extra=no','--root',root_id,'--allow-uncommitted')['payload']['graph']
    assert preview['changes']==applied['changes']
    assert 'repour:removed' in show(initial['ids']['optional']).get('labels',[])
    print(json.dumps({'event':'oracle_pass','oracle':'conditional-var-preview-apply'}),flush=True)
    example=repo/'examples/beads/release-under-epic'
    template=workspace/'attached.formula.toml.j2'; shutil.copyfile(example/'release.formula.toml.j2',template)
    req=json.loads((example/'request.json').read_text())
    parent=json.loads(bd_run('create','Attached parent','--type','epic','--json'))['id']
    req.update(working_directory=str(workspace),template=str(template),rendered_formula=str(workspace/'attached.formula.toml'),parent=parent,bd_executable=bd)
    request_path=workspace/'attach-request.json'; request_path.write_text(json.dumps(req))
    print(json.dumps({'event':'attach_input','request':req,'template':template.read_text()}),flush=True)
    def call(operation,*flags):
        return json.loads(run([binary,'bead',operation,'--request',str(request_path),'--render-by','bd',*flags,'--json'],cwd=workspace,env=env).stdout)
    created=call('attach')['payload']['graph']; build=created['ids']['build']
    bd_run('update',build,'--status','in_progress','--notes','attached runtime')
    req['compose_variables']={'version':'1.6.2'}; request_path.write_text(json.dumps(req))
    changed=call('repour','--allow-uncommitted')['payload']['graph']; row=show(build)
    assert changed['ids']['build']==build and row['title']=='Build 1.6.2' and row['status']=='in_progress' and row['notes']=='attached runtime'
    print(json.dumps({'event':'oracle_pass','oracle':'request-attach-repour'}),flush=True)

def extras_refusal():
    path=workspace/'cycle.formula.toml.j2'
    body='formula = "cycle"\nversion = 1\ntype = "workflow"\n[[steps]]\nid = "alpha"\ntitle = "Alpha"\nneeds = ["beta"]\n[[steps]]\nid = "beta"\ntitle = "Beta"\nneeds = ["alpha"]\n'
    path.write_text(body); before=snapshot()
    print(json.dumps({'event':'cycle_input','template':body}),flush=True)
    result=cli('pour',path,expected=2)
    assert result['payload']['outcome'] != 'succeeded',result
    assert snapshot()==before
    print(json.dumps({'event':'oracle_pass','oracle':'cycle-refusal-no-writes','result':result}),flush=True)
