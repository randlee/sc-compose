import json, subprocess, sys, time
from pathlib import Path
out=Path('/tmp/sc-structural-campaign')
deadline=time.monotonic()+620
for seed in range(25000,25030):
    if time.monotonic() >= deadline:
        print(json.dumps({'event':'deadline','next_seed':seed}),flush=True)
        break
    path=out / f'{seed}.log'
    command=['nice','-n','10',sys.executable,str(out/'probe.py'),str(seed)]
    print(json.dumps({'event':'start','seed':seed,'command':command,'log':str(path)}),flush=True)
    with path.open('w') as log:
        p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    print(json.dumps({'event':'end','seed':seed,'exit':p.returncode}),flush=True)
    if p.returncode != 0:
        print(json.dumps({'event':'stop_on_failure','seed':seed}),flush=True)
        break
    time.sleep(2)
print(json.dumps({'event':'complete'}),flush=True)
