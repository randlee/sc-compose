from pathlib import Path
base=Path('/tmp/sc-deep-probe-6R3u4B/probe.py').read_text()
start=base.index('seed = 24036')
end=base.index('f.plans_for_seed = plans_for_seed')
base=base[:start]+'''import random
seed = int(sys.argv[1])
rng = random.Random(seed)
names = ['alpha', 'beta', 'gamma', 'delta', 'epsilon', 'zeta'][:4 + seed % 3]
def plans_for_seed(seed):
    plans = []
    for revision in range(3):
        active = [x for x in names if not (revision == 1 and x == 'delta')]
        if revision == 1:
            active.append('delta_renamed')
        steps = []
        for i, name in enumerate(active):
            needs = [active[j] for j in range(i) if rng.randrange(3) == 0]
            steps.append({'id': name, 'title': f'{name} seed {seed} revision {revision}', 'description': f'seed={seed}; revision={revision}; node={name}', 'priority': rng.randrange(5), 'needs': needs})
        plans.append({'formula': f'fuzz_{seed}', 'steps': steps})
    return plans
''' + base[end:]
# Generate plans once, so printed input and executed input are identical.
base=base.replace("f.plans_for_seed = plans_for_seed\nprint(json.dumps({'probe':'deep_revision_chain', 'seed':seed, 'plans':plans_for_seed(seed)}, ensure_ascii=False), flush=True)","plans = plans_for_seed(seed)\nf.plans_for_seed = lambda _seed: plans\nprint(json.dumps({'probe':'structural_churn', 'seed':seed, 'plans':plans}, ensure_ascii=False), flush=True)")
base=base.replace('existing = h.server_processes()', '''original_run = h.run
def traced_run(args, *, cwd, env, expected=0):
    result = subprocess.run(args, cwd=cwd, env=env, text=True, capture_output=True, timeout=120)
    print(json.dumps({'command':args, 'exit':result.returncode, 'stdout':result.stdout, 'stderr':result.stderr}, ensure_ascii=False), flush=True)
    if result.returncode != expected:
        raise AssertionError(f'expected exit {expected}: {args}; got {result.returncode}; stdout={result.stdout}; stderr={result.stderr}')
    return result
h.run = traced_run
existing = h.server_processes()''')
base=base.replace('PASS: one graph, four plans, three revisions; seed 24036', 'PASS: one graph, three plans, two revisions')
Path('/tmp/sc-structural-campaign/probe.py').write_text(base)
