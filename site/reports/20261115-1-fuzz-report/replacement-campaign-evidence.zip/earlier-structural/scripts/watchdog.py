import os, signal, subprocess, time
runner=76802
time.sleep(450)
try:
    children=subprocess.run(['pgrep','-P',str(runner)],capture_output=True,text=True).stdout.split()
    for child in children:
        os.kill(int(child), signal.SIGINT)
    with open('/tmp/sc-structural-campaign/watchdog.log','w') as f: f.write(f'interrupted own active children {children}; cleanup requested\n')
except ProcessLookupError:
    pass
