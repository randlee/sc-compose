import json,os,random,sys,subprocess,hashlib
from pathlib import Path
seed=int(sys.argv[1]); workspace=Path(sys.argv[2]); port=sys.argv[3]
repo=Path('/Users/randlee/github/sc-compose-worktrees/sprint/w-6-adversarial-fuzz'); bd='/opt/homebrew/bin/bd'; binary=str(repo/'target/debug/sc-compose')
env=os.environ.copy(); path=workspace/f'fuzz_forty_{seed}.formula.toml.j2'; rng=random.Random(seed); chain=[f'n{i:02}' for i in range(38)]; rng.shuffle(chain)
print(json.dumps({'event':'case','seed':seed,'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'port':port}),flush=True)
def run(args,expected=0):
 p=subprocess.run(args,cwd=workspace,env=env,text=True,capture_output=True,timeout=120)
 print(json.dumps({'event':'command','args':args,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr},ensure_ascii=False),flush=True)
 if p.returncode!=expected: raise AssertionError((args,expected,p.returncode))
 return p.stdout
def cli(op,*flags,expected=0): return json.loads(run([binary,'bead',op,str(path),*flags,'--json'],expected))['payload']
def snap():
 rows=json.loads(run([bd,'list','--all','-n','0','--json']))
 for r in rows:
  if 'dependencies' in r:r['dependencies']=sorted(r['dependencies'],key=lambda x:json.dumps(x,sort_keys=True))
  if 'labels' in r:r['labels']=sorted(r['labels'])
 return {r['id']:r for r in rows}
def formula(rev):
 # 38-node seeded dependency chain, plus two identities used to exercise remove/restore/rename.
 names=chain+(['other'] if rev==1 else ['other','replacement'] if rev==3 else ['other','rename_target'])
 lines=[f'formula = "fuzz_forty_{seed}"','version = 1','type = "workflow"']
 for i,name in enumerate(names):
  needs=[names[i-1]] if 0<i<38 else []
  title=f'{name} seed {seed}' + (f' rev {rev}' if name==f'n{(seed+rev)%38:02}' else '')
  lines.extend(['[[steps]]',f'id = {json.dumps(name)}',f'title = {json.dumps(title)}',f'needs = {json.dumps(needs)}'])
 return '\n'.join(lines)+'\n'
plans=[formula(i) for i in range(11)]
print(json.dumps({'event':'inputs','seed':seed,'plans':plans},ensure_ascii=False),flush=True)
path.write_text(plans[0]); graph=cli('pour')['graph']; root=graph['parent']; original=graph['ids']['rename_target']; other=graph['ids']['other']; known=graph['ids']; last=snap(); assert len(known)==40
for rev in range(1,11):
 path.write_text(plans[rev]); before=snap(); flags=['--root',root,'--allow-uncommitted']; preview=cli('repour',*flags,'--dry-run')['graph']; assert snap()==before,'preview wrote state'; applied=cli('repour',*flags)['graph']; assert preview['changes']==applied['changes'],'preview/apply mismatch'; after=snap(); cli('repour',*flags); assert snap()==after,'repeat changed state'
 if rev==1: assert 'repour:removed' in after[original].get('labels',[])
 if rev==2: assert applied['ids']['rename_target']==original and 'repour:removed' not in after[original].get('labels',[])
 if rev==3:
  replacement=applied['ids']['replacement']; assert 'repour:removed' in after[original].get('labels',[]) and replacement!=original
 if rev==4: assert applied['ids']['rename_target']==original and 'repour:removed' not in after[original].get('labels',[]) and 'repour:removed' in after[replacement].get('labels',[])
 print(json.dumps({'event':'revision_pass','seed':seed,'revision':rev}),flush=True)
print(json.dumps({'event':'case_pass','seed':seed,'nodes':40,'revisions':10}),flush=True)
