import datetime, json, os, queue, shutil, signal, subprocess, sys, tempfile, threading, time
from pathlib import Path
from contextlib import ExitStack
repo=Path('/Users/randlee/github/sc-compose-worktrees/sprint/w-6-adversarial-fuzz')
sys.path.insert(0,str(repo/'scripts'))
import integration_repour as h
out=Path('/tmp/sc-forty-campaign')
deadline=datetime.datetime(2026,11,16,7,27,30,tzinfo=datetime.timezone.utc)
def remaining(): return (deadline-datetime.datetime.now(datetime.timezone.utc)).total_seconds()
servers=h.server_processes()
assert all('shared-server' in s for s in servers),servers
assert remaining()>30
root=Path(tempfile.mkdtemp(prefix='server-',dir=out)).resolve()
owned=[]
with ExitStack() as stack:
    stack.callback(h.cleanup_root,root,owned)
    home,data=root/'home',root/'data'; home.mkdir(); data.mkdir()
    env={k:v for k,v in os.environ.items() if not k.startswith(('BEADS_','BD_DOLT_'))}
    env.update(HOME=str(home),USERPROFILE=str(home),XDG_CONFIG_HOME=str(home/'.config'),DOLT_ROOT_PATH=str(home),DOLT_DISABLE_EVENT_FLUSH='1',BD_DISABLE_EVENT_FLUSH='1',BD_DISABLE_METRICS='1')
    dolt='/opt/homebrew/bin/dolt'
    for k,v in [('versioncheck.disabled','true'),('user.name','integration'),('user.email','integration@example.invalid')]: h.run([dolt,'config','--global','--add',k,v],cwd=data,env=env)
    port=h.select_server_port(None)
    assert port!=3308
    log=stack.enter_context((out/'server.log').open('wb'))
    server=subprocess.Popen(['nice','-n','10',dolt,'sql-server','--host','127.0.0.1','--port',str(port)],cwd=data,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    owned.append(server)
    events=queue.Queue(); reader=threading.Thread(target=h.read_server_output,args=(server.stdout,log,port,events),daemon=True); reader.start()
    stack.callback(server.stdout.close); stack.callback(h.join_server_reader,reader); stack.callback(h.stop_server,server)
    h.wait_for_server(events,server,out/'server.log')
    print(json.dumps({'event':'server_started','port':port,'pid':server.pid,'deadline':deadline.isoformat()}),flush=True)
    workspace=root/'workspace'; workspace.mkdir()
    env.update(BEADS_DIR=str(workspace/'.beads'),BEADS_NO_DAEMON='1',BD_DOLT_AUTO_PUSH='false',BD_DOLT_LOCAL_ONLY='true',SC_COMPOSE_TEST_DOLT_PORT=str(port))
    cmd=['nice','-n','10','/opt/homebrew/bin/bd','init','--non-interactive','--quiet','--skip-agents','--skip-hooks','--prefix','it','--server','--server-port',str(port),'--database','campaign']
    result=subprocess.run(cmd,cwd=workspace,env=env,text=True,capture_output=True,timeout=120)
    print(json.dumps({'event':'init','command':cmd,'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr}),flush=True)
    assert result.returncode==0
    cases=[('forty',seed) for seed in range(5)]
    for kind,seed in cases:
        if remaining()<40:
            print(json.dumps({'event':'deadline','unstarted':[kind,seed]}),flush=True); break
        path=out/f'{kind}-{seed}.log'; cmd=['nice','-n','10',sys.executable,str(out/'case.py'),str(seed),str(workspace),str(port)]
        print(json.dumps({'event':'start','kind':kind,'seed':seed,'command':cmd,'log':str(path)}),flush=True)
        with path.open('w') as logfile:
            p=subprocess.Popen(cmd,stdout=logfile,stderr=subprocess.STDOUT,start_new_session=True)
            try: code=p.wait(timeout=min(500,max(1,remaining()-30)))
            except subprocess.TimeoutExpired:
                os.killpg(p.pid,signal.SIGINT)
                try: p.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(p.pid,signal.SIGKILL); p.wait()
                print(json.dumps({'event':'timeout','kind':kind,'seed':seed}),flush=True); break
        print(json.dumps({'event':'end','kind':kind,'seed':seed,'exit':code}),flush=True)
        if code!=0:
            print(json.dumps({'event':'case_failed','kind':kind,'seed':seed}),flush=True)
        time.sleep(2)
print(json.dumps({'event':'servers_after','processes':sorted(h.server_processes())}),flush=True)
