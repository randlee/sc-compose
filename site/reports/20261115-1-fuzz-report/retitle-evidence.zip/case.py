import json, os, sys, subprocess, hashlib
from pathlib import Path
from guard import isolated_env
seed=int(sys.argv[1]); workspace=Path(sys.argv[2]); port=sys.argv[3]; env=isolated_env(os.environ,workspace,port)
bd='/opt/homebrew/bin/bd'; binary='/Users/randlee/github/sc-compose-worktrees/sprint/w-6-adversarial-fuzz/target/debug/sc-compose'; path=workspace/'retitle.formula.toml.j2'
def run(args,expected=0):
 p=subprocess.run(args,cwd=workspace,env=env,text=True,capture_output=True,timeout=120)
 print(json.dumps({'event':'command','args':args,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr},ensure_ascii=False),flush=True)
 assert p.returncode==expected,(args,p.returncode,expected)
 return p.stdout
def cli(op,*args):return json.loads(run([binary,'bead',op,str(path),*args,'--json']))['payload']['graph']
def snap():
 rows=json.loads(run([bd,'list','--all','-n','0','--json']))
 for r in rows:
  if 'dependencies' in r:r['dependencies']=sorted(r['dependencies'],key=lambda x:json.dumps(x,sort_keys=True))
  if 'labels' in r:r['labels']=sorted(r['labels'])
 return {r['id']:r for r in rows}
assert 'campaign' in run([bd,'sql','--readonly','SELECT DATABASE() AS db','--json'])
print(json.dumps({'event':'preflight','generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'home':env['HOME'],'beads_dir':env['BEADS_DIR'],'port':port,'database':'campaign'}),flush=True)
titles=['Starting title','Unicode 雪 café','Double "quotes" and apostrophe \'','Line one\nLine two','Unicode 雪 café']
plans=['formula = "retitle"\nversion = 1\ntype = "workflow"\n[[steps]]\nid = "same"\ntitle = '+json.dumps(t,ensure_ascii=False)+'\n' for t in titles]
print(json.dumps({'event':'inputs','plans':plans},ensure_ascii=False),flush=True)
path.write_text(plans[0]); graph=cli('pour'); root=graph['parent']; bead=graph['ids']['same']
run([bd,'update',bead,'--status','in_progress','--notes','retitle runtime','--add-label','user:retitle'])
for i,plan in enumerate(plans[1:],1):
 path.write_text(plan); before=snap(); flags=['--root',root,'--allow-uncommitted']; preview=cli('repour',*flags,'--dry-run'); assert snap()==before
 applied=cli('repour',*flags); assert preview['changes']==applied['changes'] and applied['ids']['same']==bead
 after=snap(); row=after[bead]; assert row['title']==titles[i] and row['status']=='in_progress' and row['notes']=='retitle runtime' and 'user:retitle' in row['labels']
 cli('repour',*flags); assert snap()==after
 print(json.dumps({'event':'revision_pass','revision':i,'title':titles[i]},ensure_ascii=False),flush=True)
print(json.dumps({'event':'case_pass','seed':seed,'nodes':1,'revisions':4}),flush=True)
